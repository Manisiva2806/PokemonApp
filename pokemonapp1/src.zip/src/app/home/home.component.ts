import { Component, OnInit } from '@angular/core';
import { PokeserviceService } from '../pokeservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  i:any;
  pokemons:any[]=[];
  constructor(private service:PokeserviceService) { }

  ngOnInit(): void {
    this.service.getPokemons().
    subscribe((response:any)=>{
      response.results.forEach((result:any)=>{
        this.service.getMorePokemons(result.name).
        subscribe((uniqueResponse:any)=>{
          this.pokemons.push(uniqueResponse);
          console.log(this.pokemons);
        });
      });
    });
  }


}
