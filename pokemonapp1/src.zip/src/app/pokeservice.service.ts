import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Details } from './details';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class PokeserviceService {

  data:any;
  constructor(private http:HttpClient) { }

  public loginUserFromRemote(user:User):Observable<any>{
    return this.http.post<any>("http://localhost:8090/login",user)
  }
  public SignupUserFromRemote(user:User):Observable<any>{
    return this.http.post<any>("http://localhost:8090/registeruser",user)
  }

  getPokemons(){
    return this.http.get(`https://pokeapi.co/api/v2/pokemon?limit=150`);
  }

  getMorePokemons(name : string){
    return this.http.get(`https://pokeapi.co/api/v2/pokemon/${name}`);
  }

  getDetailsById(id:number):Observable<Details>{
    return this.http.get<Details>(`https://pokeapi.co/api/v2/pokemon/${id}`);
  }
}
